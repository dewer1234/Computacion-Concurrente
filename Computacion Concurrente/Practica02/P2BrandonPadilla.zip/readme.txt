Brandon Padilla Ruiz
312139805

La clase principal se encuentra en el archivo Practica02.java
